'use strict';

var DashboardServices = angular.module('DashboardServices', []);
DashboardServices.service('DashboardServices', function($http, $q) {

	var baseUrl='http://localhost:8080';
	
	return {
		login:login,
		logout:logout,
		getUsers:getUsers,
		addUser:addUser,
		removeUser:removeUser,
		getRecords:getRecords,
		addRecord:addRecord
	};

	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	// Login
	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	function login(req) {
		var request = $http({
			method : 'POST',
			data : req,
			dataType : 'json',
			url : baseUrl+'/login',
			cache : false
		});
		return request.then(handleSuccess, handleError);
	}
	
	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	// Logout
	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	function logout(req) {
		var request = $http({
			method : 'POST',
			data : req,
			dataType : 'json',
			url : baseUrl+'/logout',
			cache : false
		});
		return request.then(handleSuccess, handleError);
	}
	
	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	// Get Record
	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	function getRecords(req) {
		var request = $http({
			method : 'POST',
			data : req,
			dataType : 'json',
			url : baseUrl+'/getRecords',
			cache : false
		});
		return request.then(handleSuccess, handleError);
	}
	
	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	// Set Record
	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	function setRecord(req) {
		var request = $http({
			method : 'POST',
			data : req,
			dataType : 'json',
			url : baseUrl+'/setRecord',
			cache : false
		});
		return request.then(handleSuccess, handleError);
	}
	
	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	// ADD TRANSACTION RECORDS
	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	function addRecord(req) {
		var request = $http({
			method : 'POST',
			data : req,
			dataType : 'json',
			url : baseUrl+'/addRecord',
			cache : false
		});
		return request.then(handleSuccess, handleError);
	}
	
	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	// REMOVE TRANSACTION RECORDS
	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	function removeUser(req)
	{
		var request = $http({
			method : 'POST',
			data : req,
			dataType : 'json',
			url : baseUrl+'/deleteuser',
			cache : false
		});
		return request.then(handleSuccess, handleError);
	}
	
	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	// GET USERS
	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	function getUsers(req) {
		var request = $http({
			method : 'POST',
			data : req,
			dataType : 'json',
			url : baseUrl+'/users',
			cache : false
		});
		return request.then(handleSuccess, handleError);
	}
	
	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	// ADD USERS
	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	function addUser(req) {
		var request = $http({
			method : 'POST',
			data : req,
			dataType : 'json',
			url : baseUrl+'/adduser',
			cache : false
		});
		return request.then(handleSuccess, handleError);
	}
	
	function handleSuccess(response) {
		return response.data;
	}

	function handleError(response) {
		if (!angular.isObject(response.data) || !response.data.message) {
			return $q.reject("An unknown error occurred.")
		}

		return $q.reject(response.data.message);
	}

	
})
'use strict';

var dashboardControllers = angular.module('dashboardControllers', []);

dashboardControllers
		.controller(
				'dashboardController',
				[
						'$scope',
						'DashboardServices',
						'$http',
						function($scope, DashboardServices, $http) {
							$scope.processTransactions=[];
							$scope.applicationState="Login";
							$scope.recordCounts=["5","10","20","50"];
							$scope.pageNumberCount=["1"];
							$scope.userRoles=["USER","ADMIN"];
							$scope.tableMode="PROCESS";
							$scope.schedules=[];
							$scope.credentails=[];
							$scope.newSchedule=false;
							$scope.passwordVisibleStatus=false;
							$scope.processNames=[];
							$scope.commandList=[];
							$scope.login={};
							$scope.commandViewarray=[];
							$scope.userRole="ADMIN";
							//$scope.userRole="USER";
							$scope.viewPicture=false;
							$scope.record={};
							$scope.transaction=[];
							//capute image
							 $scope.width = 320;    // We will scale the photo width to this
							 $scope.height = 0;     // This will be computed based on the input stream
							 $scope.streaming = false;
							 $scope.video=null;
							 $scope.canvas=null;
							 $scope.photo=null;
							 $scope.totalCount=0;
							 $scope.selectedNumberOfRecords=5;
							 $scope.activePage=0;
							 $scope.captureMode=true;
							 
							$scope.init = function() {
								$scope.record={};
								// Load records from File DB
								$scope.getRecords();
								$scope.getUser();
							}
							
							/********************************************************************************************************/
							/******************************************   CAMERA ACTIONS  *******************************************/
							/********************************************************************************************************/
							
							// video camera handling
							$scope.startStreaming=function()
							{
								$scope.video = document.getElementById('video');	
								$scope.canvas = document.getElementById('canvas');
								$scope.photo = document.getElementById('photo');
								
								// get connection with web camera
								navigator.mediaDevices.getUserMedia({video: true, audio: false})
								    .then(function(stream) {
								    	$scope.video.srcObject = stream;
								    	$scope.track = stream.getTracks()[0]; 
								    	$scope.video.play();
								    })
								    .catch(function(err) {
								      console.log("UNABLE TO DETECT WEB CAMERA, PLEASE VERIFY THE CAMERA CONNECTION: " + err);
								    });
								
								
								// START CAPTURING VIDEO STREAM
								 $scope.video.addEventListener('canplay', function(ev){
								      if (!$scope.streaming) {
								    	  $scope.height = $scope.video.videoHeight / ($scope.video.videoWidth/$scope.width);
								      
								        // Firefox currently has a bug where the height can't be read from
								        // the video, so we will make assumptions if this happens.
								      
								        if (isNaN($scope.height)) {
								        	$scope.height = $scope.width / (4/3);
								        }
								      
								        $scope.video.setAttribute('width', $scope.width);
								        $scope.video.setAttribute('height', $scope.height);
								        $scope.canvas.setAttribute('width', $scope.width);
								        $scope.canvas.setAttribute('height', $scope.height);
								        $scope.streaming = true;
								        console.log("stream status from video event : "+$scope.streaming);
								      }
								    }, false);
								 $scope.viewPicture=true;
							}
							
							$scope.stopStreaming=function()
							{
								$scope.track.stop();
							}
								
								
						 // Capture a photo by fetching the current contents of the video
						  // and drawing it into a canvas, then converting that to a PNG
						  // format data URL. By drawing it on an offscreen canvas and then
						  // drawing that to the screen, we can change its size and/or apply
						  // other changes before drawing it.

						  $scope.takepicture=function() {
							  
						    var context = $scope.canvas.getContext('2d');
						    if ($scope.width && $scope.height) {
						    	$scope.canvas.width = $scope.width;
						    	$scope.canvas.height = $scope.height;
						    	context.drawImage(video, 0, 0, $scope.width, $scope.height);
						    
						    $scope.record.imageStream = $scope.canvas.toDataURL('image/png');
						    $scope.photo.setAttribute('src', $scope.record.imageStream);
						    } else {
						    	$scope.clearphoto();
						    }
						    $scope.viewPicture=!$scope.viewPicture;	
						    $scope.stopStreaming(); // stop ctreaming
						  }
						  
						  // Fill the photo with an indication that none has been captured.
						  $scope.clearphoto=function() {
						    var context = $scope.canvas.getContext('2d');
						    context.fillStyle = "#AAA";
						    context.fillRect(0, 0, $scope.canvas.width, $scope.canvas.height);

						    $scope.imgData = $scope.canvas.toDataURL('image/png');
						    $scope.photo.setAttribute('src', $scope.imgData);
						  }
						  
						  // view photo
						  $scope.viewPhoto=function(index)
						  {
							  $scope.captureMode=false;
							  var stream = "data:image/png;base64,"+$scope.transaction[index].image;
							  var photo = document.getElementById('photoViewer');
							  photo.setAttribute('src', stream);
						  }
						  
						  $scope.flipCM=function()
						  {
							  $scope.captureMode=!$scope.captureMode;
						  }
						  
						  	/********************************************************************************************************/
							/******************************************    USER ACTIONS   *******************************************/
							/********************************************************************************************************/
						
						  
							$scope.userLogin=function()
							{
								DashboardServices.login($scope.login).then(
										function(data) {
											if (data != undefined && data != null && data.code=="200" ) 
											{
												$scope.login.status="ACTIVE";
												$scope.login.role=data.role;
												$scope.applicationState="Dashboard";
												$scope.login.api_key=data.api_key;
												$scope.init();
											}
											else
											{
												alert("Exception : "+data.message);
											}
										});
								
								
							}
							
							$scope.logout=function()
							{
								DashboardServices.logout($scope.login).then(
										function(data) {
											if (data != undefined && data != null && data.code=="200" ) 
											{
												$scope.login.status="INACTIVE";
												$scope.applicationState="Login";
												$scope.login.api_key=data.api_key;
											}
											else
											{
												alert("Exception : "+data.message);
											}
										});
								
								
							}
							
							// Get all users
							$scope.getUser=function()
							{
								DashboardServices.getUsers($scope.login).then(
										function(data) {
											if (data != undefined && data != null && data.code=="200" ) 
											{
												$scope.credentails=data.users;
												
												for(let i=0;i<$scope.credentails.length;i++)
												{
													$scope.credentails[i].saved=true;
												}
											}
											else
											{
												alert("Exception : "+data.message);
											}
										});
							}
							
							// Update User
							$scope.updateCred=function(index)
							{
								var req={};
								  req.api_key=$scope.login.api_key;
								  req.userName=$scope.login.userName;
								  req.user=$scope.credentails[index];
								
								// field validation
								DashboardServices.addUser(req).then(
										function(data) {
											if (data != undefined && data != null && data.code=="200" ) 
											{
												alert("User Details Saved !");
												$scope.credentails[index].saved=true;
											}
											else
											{
												alert("Exception : "+data.message);
											}
										});
								
							}
							

							// Add user
							$scope.deleteCredentail=function(index)
							{
								var name = prompt("Write User Name !", null);
								if (name == $scope.credentails[index].userName) {
									var req={};
									  req.api_key=$scope.login.api_key;
									  req.userName=$scope.login.userName;
									  req.user=$scope.credentails[index];
									  
									// field validation
									DashboardServices.removeUser(req).then(
											function(data) {
												if (data != undefined && data != null && data.code=="200" ) 
												{
													alert("User Deleted Successfully !");
													$scope.credentails.splice(index,1);
												}
												else
												{
													alert("Exception : "+data.message);
												}
											});
									
								}
								else
								{
									alert("User Deleted Successfully !");
								}
							}
							
							/********************************************************************************************************/
							/****************************************** GET TRANSACTIONS  *******************************************/
							/********************************************************************************************************/
							
							  // save data into DB
							  $scope.saveTransaction=function()
							  {
								  if($scope.verifyNull($scope.record.first_id) && $scope.verifyNull($scope.record.first_id_match) && $scope.verifyNull($scope.record.second_id) 
										  && $scope.verifyNull($scope.record.second_id_match) && $scope.verifyNull($scope.record.cargo_shipment_acceptor) && $scope.verifyNull($scope.record.shipper_company_name) 
										  && $scope.verifyNull($scope.record.iac_employee) && $scope.verifyNull($scope.record.imageStream))
								  {
										var req={};
									    req.api_key=$scope.login.api_key;
									    req.userName=$scope.login.userName;
									    req.transaction=$scope.record;
									    
									    DashboardServices.addRecord(req).then(
												function(data) {
													if (data != undefined && data != null && data.code=="200") 
													{
														alert("Record Saved Successfully !");
														$scope.record={};
														/*$scope.record.first_id=null;
														$scope.record.first_id_match=null;
														$scope.record.second_id=null;
														$scope.record.second_id_match=null;
														$scope.record.cargo_shipment_acceptor=null;
														$scope.record.shipper_company_name=null;
														$scope.record.iac_employee=null;
														$scope.record.imageStream=null;*/
													}
													else
													{
														alert("Exception : "+data.message);
													}
												});
								  }
								  else
								  {
									  
									  alert("VALIDATION FAILED ! PROVIDE ALL VALUES");
								  }
							  }
							
							  /**
							   *  Fetch records from DB 
							   * */
							$scope.getRecords = function(startIndex,endIndex) {
								
								var req={};
								req.api_key=$scope.login.api_key;
								req.userName=$scope.login.userName;
									
								if($scope.verifyNull(startIndex) && $scope.verifyNull(endIndex))
								{
									req.startIndex=startIndex;
									req.endIndex=endIndex;
								}
							
								DashboardServices.getRecords(req).then(
												function(data) {
													$scope.transaction=[];
													if (data.code=="200" && data != null) 
													{
														$scope.transaction = data.transaction;
														$scope.postRecordUpdate(data.count);
													}
													else
													{
														alert("Exception : "+data.message);
													}
												});
							}
							
							// pagination actions
							$scope.postRecordUpdate=function(count)
							{
								$scope.totalCount=count; // update total count
								$scope.pageNumberCount=[]; // set pagination page view
								
								var temp=$scope.totalCount;
								var index=1;
								
								while(temp>0)
								{
									temp=temp-$scope.selectedNumberOfRecords;
									$scope.pageNumberCount.push(index);
									index++;
								}
							}
							
							/* download imag3 */
							$scope.downloadImage=function(index)
							{
								var prefix="data:image/png;base64,";
								var base64 = prefix+$scope.transaction[index].image;
								$scope.saveAsFile(base64,$scope.transaction[index].first_id);
								
							}
							
							  //download pic
							  $scope.saveAsFile=function(base64,fileName) {
								    var link = document.createElement("a");
								    link.setAttribute("href", base64);
								    link.setAttribute("download", fileName);
								    link.click();
								}
							
							  
							  
							  $scope.onCountChange=function(selectedNumberOfRecords)
							  {
								  $scope.selectedNumberOfRecords=selectedNumberOfRecords // update centralised variable
								  var startIndex=parseInt($scope.totalCount)-parseInt(selectedNumberOfRecords);
								  var endIndex=$scope.totalCount
								  if(startIndex<0)
								  {
									  startIndex=0;
								  }
								  $scope.getRecords(startIndex,endIndex);
							  }
							  
							  
							  $scope.selectPage=function(page)
							  {
								  $scope.activePage=page-1;
								  var startIndex =parseInt($scope.totalCount)-parseInt($scope.selectedNumberOfRecords)*parseInt(page);
								  var endIndex = parseInt(startIndex)+parseInt($scope.selectedNumberOfRecords);
								  $scope.getRecords(startIndex,endIndex);
							  }
							  
							/********************************************************************************************************/
							/************************************************utility function****************************************/
							/********************************************************************************************************/
							
							$scope.setTasks=function(row,index)
							{
								$scope.selectedTasks=row;
								$scope.tableMode="TASK";
							}
							
							$scope.setProcessView=function()
							{
								$scope.tableMode="PROCESS";
							}
							
							$scope.deleteRow=function(array)
							{
								array.push({});
							}
							
							$scope.addRow=function(credential)
							{
								credential.push({});
							}
							
							$scope.toggleEnable = function(index, array) {
								if (array[index].saved == undefined) {
									array[index].saved = false;
								} else {
									array[index].saved = !array[index].saved;
								}
							}
							
							$scope.verifyNull=function(data)
							{
								if(data==undefined || data==null || data=="")
								{
									return false;
								}
								else
								{
									return true;
								}
							}
							
							
							
							
							/********************************************************************************************************/
							/************************************************ PDF GENERATION ****************************************/
							/********************************************************************************************************/
							
							$scope.downloadPDF_v1=function(index)
							{
								$scope.record=$scope.transaction[index];
								
								setTimeout({}, 3000);
							//	$scope.saveAsPDF(document.getElementById('table-container').innerHTML,$scope.transaction[index].first_id);
								
								var element =document.getElementById('table-container');
								var divHeight = $('#table-container').height();
								var divWidth = $('#table-container').width();
								var ratio = divHeight / divWidth;
								
								html2canvas(document.getElementById('table-container')).then(function(canvas){
							        var wid;
							        var hgt;
							        var img = canvas.toDataURL("image/jpeg", wid = canvas.width, hgt = canvas.height);
							        var hratio = hgt/wid
							        var doc = new jsPDF('p','pt','a4');
							        var width = doc.internal.pageSize.width;    
							        var height = width * hratio
							        doc.addImage(img,'JPEG',20,20, width, height);
							        doc.save('Test.pdf');
							    });
								
								
								/*html2canvas(element, {
								     height: divHeight,
								     width: divWidth,
								     onrendered: function(canvas) {
								          var image = canvas.toDataURL("image/jpeg",1);
								          var doc = new jsPDF("p", "mm", "a4"); // using defaults: orientation=portrait, unit=mm, size=A4
								          var width = doc.internal.pageSize.getWidth();    
								          var height = doc.internal.pageSize.getHeight();
								        
								          height = ratio * width;
								          doc.addImage(image, 'JPEG', 0, 0, width-20, height-10);
								          doc.save('myPage.pdf'); //Download the rendered PDF.
								     }
								});
								*/
								
									
									/* // workign code
									  html2canvas(document.body).then(function (canvas) {
								      var base64encodedstring = canvas.toDataURL("image/jpeg", 1);
								     var img=$('#img').attr('src', base64encodedstring);
								   
							         // var doc = new jsPDF();
								     var doc = new jsPDF("p", "mm", "a4");
								     
								     var width = doc.internal.pageSize.getWidth();    
							         var height = doc.internal.pageSize.getHeight();
							         height = ratio * width;

									   doc.addImage(base64encodedstring,'JPEG',0, 0, width, height);
									   doc.save('test3.pdf');
								    });
									*/
								
								/* html2canvas(document.getElementById('table-container'),{
									   onrendered:function(canvas){
										   
									   var img=canvas.toDataURL("image/png");
									   var doc = new jsPDF();
									   doc.addImage(img,'JPEG',20,20);
									   doc.save('test.pdf');
										   
										   var docDefinition = {
								                    content: [{
								                        image: data,
								                        width: 500,
								                    }]
								                };
								           pdfMake.createPdf(docDefinition).download("Score_Details.pdf");
									   }

									   });*/
							}
							
							$scope.saveAsPDF=function(data,fileName)
							{
								 var pdf = new jsPDF('p','pt','a4');
								 var margins = {top: 25,bottom: 60,left: 20,width: 522};
								 pdf.addHTML(data, margins.top, margins.left, {}, function() {pdf.save('test.pdf');});
								$scope.savePDF();
							}

							 $scope.savePDF = function(){
							      var pdf = new jsPDF('p','pt','a4');
							      //var source = document.getElementById('table-container').innerHTML;
							      console.log(document.getElementById('table-container'));
							      var margins = {
							        top: 25,
							        bottom: 60,
							        left: 20,
							        width: 522
							      };
							      
							      pdf.addHTML(document.getElementById('table-container'), margins.top, margins.left, {}, function() {
								       pdf.save('test2.pdf');
								     });
							      // all coords and widths are in jsPDF instance's declared units
							      // 'inches' in this case
							     //pdf.text(20, 20, 'Hello world.');
							   /*  pdf.addHTML(document.body, margins.top, margins.left, {}, function() {
							       pdf.save('test.pdf');
							     });*/
							      
							    };
							    
							    
							    /********************************************************************************************************/
								/***************************************** PDF GENERATION AS TEXT****************************************/
								/********************************************************************************************************/
								
							    $scope.base64Img = null;
							    
							    $scope.imgToBase64=function(url, callback, imgVariable) {
							        if (!window.FileReader) {
							            callback(null);
							            return;
							        }
							        var xhr = new XMLHttpRequest();
							        xhr.responseType = 'blob';
							        xhr.onload = function() {
							            var reader = new FileReader();
							            reader.onloadend = function() {
							    			imgVariable = reader.result.replace('text/xml', 'image/jpeg');
							                callback(imgVariable);
							            };
							            reader.readAsDataURL(xhr.response);
							        };
							        xhr.open('GET', url);
							        xhr.send();
							    };
							    
							    
							    $scope.imgToBase64('img/logo.jpg', function(base64) {
							    	$scope.base64Img = base64; 
							    });
							    
							    $scope.margins = {
							    		  top: 70,
							    		  bottom: 40,
							    		  left: 30,
							    		  width: 550
							    		};
							    
							    $scope.downloadPDF=function(index)
								{
									$scope.record=$scope.transaction[index];
								}
							    
							    $scope.generate=function()
							    {
							    	var pdf = new jsPDF('p', 'pt', 'a4');
							    	pdf.setFontSize(18);
							    	pdf.fromHTML(document.getElementById('table-container'), 
							    		$scope.margins.left, // x coord
							    		$scope.margins.top,
							    		{
							    			// y coord
							    			width: $scope.margins.width// max width of content on PDF
							    		},function(dispose) {
							    			$scope.headerFooterFormatting(pdf, pdf.internal.getNumberOfPages());
							    		}, 
							    		$scope.margins);
							    }
							    
							    $scope.headerFooterFormatting=function(doc, totalPages)
							    {
							    	doc.setPage(0);                            
							    	$scope.header(doc);
							    	$scope.footer(doc, 0, totalPages);
							    };

							    $scope.header=function(doc)
							    {
							        doc.setFontSize(30);
							        doc.setTextColor(40);
							        doc.setFontStyle('normal');
							    	
							        if ($scope.base64Img) {
							           doc.addImage($scope.base64Img, 'JPEG', $scope.margins.left, 10, 40,40);        
							        }
							    };

							    $scope.footer=function(doc, pageNumber, totalPages){
							        var str = "Page " + pageNumber + " of " + totalPages
							        doc.setFontSize(10);
							        doc.text(str, $scope.margins.left, doc.internal.pageSize.height - 20);
							    	doc.save('sample-document.pdf');
							    };
							    
							    
							    $scope.changeApplicationState=function(state)
							    {
							    	$scope.previousState=$scope.applicationState
							    	$scope.applicationState=state;
							    }
							    
						} ]);

package com.dm.SpringRest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.dm.request.TransactionRequest;
import com.dm.response.Response;
import com.dm.response.TransactionResponse;
import com.dm.service.DashBoardServiceImpl;

@RestController
public class DashboardController {
	
	private static Logger logger  = Logger.getLogger(DashboardController.class);
	
	@Autowired
	@Qualifier("dashboardService")
	DashBoardServiceImpl dashboardService;
	
	@CrossOrigin
    @RequestMapping(value="/getRecords",method=RequestMethod.POST)
    public TransactionResponse getRecords(@RequestBody TransactionRequest request) {
		logger.info("Get ALl Transacgtion Records");
		TransactionResponse response = new TransactionResponse();
		
		try {
			if(dashboardService.verifyToken(request))
			{
				response.setTransaction(dashboardService.getTransactions(request));
				response.setApi_key(request.getApi_key());
				response.setCount(dashboardService.getRecordCount());
				response.setCode("200");
				response.setMessage("Success");
			}
			else
			{
				response.setCode("401");
				response.setMessage("Authenication Failed");
			}
		}
		catch(Exception e)
		{
			response.setCode("500");
			response.setMessage(e.getMessage());
		}
		return response;
    }

	@CrossOrigin
    @RequestMapping(value="/addRecord",method=RequestMethod.POST)
    public Response addRecords(@RequestBody TransactionRequest request) {
		logger.info("Add Transaction request");
		Response response = new Response();
		try {
			if(dashboardService.verifyToken(request))
			{
				if(dashboardService.setTransaction(request.getTransaction()))
				{
					response.setApi_key(request.getApi_key());
					response.setCode("200");
					response.setMessage("Success");
				}
				else
				{
					response.setApi_key(request.getApi_key());
					response.setCode("500");
					response.setMessage("RECORD NOT ADDED");
				}
			}
			else
			{
				response.setCode("401");
				response.setMessage("Authenication Failed");
			}
		}
		catch(Exception e)
		{
			response.setCode("500");
			response.setMessage(e.getMessage());
		}
		return response;
    }

	/*@CrossOrigin
    @RequestMapping(value="/uploadimg",method=RequestMethod.POST)
    public Response uploadImage(@RequestBody ImageRequest request) {
		logger.info("Engine user logoff ");
		Response response = new Response();
		try {
			if(imageService.saveImage(request))
			{
				response.setApi_key(request.getApi_key());
				response.setCode("200");
				response.setMessage("Success");
			}
			else
			{
				response.setApi_key(request.getApi_key());
				response.setCode("500");
				response.setMessage("REQUEST PAYLOAD MODIFICATION DETECTED ! CLOSE BROWSE WINDOW");
			}
		}
		catch(Exception e)
		{
			response.setCode("500");
			response.setMessage(e.getMessage());
		}
		return response;
    }*/
}

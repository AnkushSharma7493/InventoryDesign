package com.dm.SpringRest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.dm.domain.User;
import com.dm.request.BaseRequest;
import com.dm.request.LoginRequest;
import com.dm.request.UserRequest;
import com.dm.response.Response;
import com.dm.response.UserResponse;
import com.dm.service.UserServiceImpl;

@RestController
public class UserController {
	
	private static Logger logger  = Logger.getLogger(UserController.class);
	
	@Autowired
	@Qualifier("userService")
	UserServiceImpl userService;
	
	@CrossOrigin
    @RequestMapping(value="/login",method=RequestMethod.POST)
    public Response login(@RequestBody LoginRequest request) {
		logger.info("System Login Request");
		UserResponse response = new UserResponse();
		User user = userService.login(request);
		
		try {
			if(user!=null && user.getApiKey()!=null)
			{
				response.setApi_key(user.getApiKey());
				response.setRole(user.getRole());
				response.setCode("200");
				response.setMessage("Success");
			}
			else
			{
				response.setCode("401");
				response.setMessage("Authenication Failed");
			}
		}
		catch(Exception e)
		{
			response.setCode("500");
			response.setMessage(e.getMessage());
		}
		return response;
    }

	@CrossOrigin
    @RequestMapping(value="/logout",method=RequestMethod.POST)
    public Response logout(@RequestBody LoginRequest request) {
		logger.info("Engine user logoff ");
		Response response = new Response();
		try {
			if(userService.logout(request))
			{
				response.setApi_key(null);
				response.setCode("200");
				response.setMessage("Success");
			}
			else
			{
				response.setApi_key(request.getApi_key());
				response.setCode("500");
				response.setMessage("REQUEST PAYLOAD MODIFICATION DETECTED ! CLOSE BROWSE WINDOW");
			}
		}
		catch(Exception e)
		{
			response.setCode("500");
			response.setMessage(e.getMessage());
		}
		return response;
    }


	@CrossOrigin
    @RequestMapping(value="/users",method=RequestMethod.POST)
    public UserResponse getAllUsers(@RequestBody BaseRequest request) {
		logger.info("Engine user logoff ");
		UserResponse response = new UserResponse();
		
		try {
				response.setUsers(userService.getAllUsers(request));
				response.setApi_key(request.getApi_key());
				response.setCode("200");
				response.setMessage("Success");
		}
		catch(Exception e)
		{
			response.setCode("500");
			response.setMessage(e.getMessage());
		}
		return response;
    }
	


	@CrossOrigin
    @RequestMapping(value="/adduser",method=RequestMethod.POST)
    public Response addUser(@RequestBody UserRequest request) {
		logger.info("Engine user logoff ");
		UserResponse response = new UserResponse();
		
		try {
				if(userService.addUser(request))
				{
					response.setApi_key(request.getApi_key());
					response.setCode("200");
					response.setMessage("Success");
				}
				else
				{
					response.setApi_key(request.getApi_key());
					response.setCode("500");
					response.setMessage("USER NOT ADDED");
				}
		}
		catch(Exception e)
		{
			response.setCode("500");
			response.setMessage(e.getMessage());
		}
		return response;
    }
	

	@CrossOrigin
    @RequestMapping(value="/deleteuser",method=RequestMethod.POST)
    public Response deleteUser(@RequestBody UserRequest request) {
		logger.info("Delete Engine user ");
		UserResponse response = new UserResponse();
		
		try {
				if(userService.deleteUser(request))
				{
					response.setApi_key(request.getApi_key());
					response.setCode("200");
					response.setMessage("Success");
				}
				else
				{
					response.setApi_key(request.getApi_key());
					response.setCode("500");
					response.setMessage("USER NOT ADDED");
				}
		}
		catch(Exception e)
		{
			response.setCode("500");
			response.setMessage(e.getMessage());
		}
		return response;
    }
	
	/*@CrossOrigin
    @RequestMapping(value="/uploadimg",method=RequestMethod.POST)
    public Response uploadImage(@RequestBody ImageRequest request) {
		logger.info("Engine user logoff ");
		Response response = new Response();
		try {
			if(imageService.saveImage(request))
			{
				response.setApi_key(request.getApi_key());
				response.setCode("200");
				response.setMessage("Success");
			}
			else
			{
				response.setApi_key(request.getApi_key());
				response.setCode("500");
				response.setMessage("REQUEST PAYLOAD MODIFICATION DETECTED ! CLOSE BROWSE WINDOW");
			}
		}
		catch(Exception e)
		{
			response.setCode("500");
			response.setMessage(e.getMessage());
		}
		return response;
    }*/

}

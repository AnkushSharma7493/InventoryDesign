package com.dm.configuration;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Base64;
import java.util.Date;
import java.util.Random;

public class UtilityHealper {
	
	public static String generateKey()
	{
		String key="";
		Random random = new Random();
		
		for(int i=0;i<20;i++)
		{
			Integer x=random.nextInt(10);
			key+=x.toString();
		}
		return key;
	}
	
	public boolean saveToLocalDirectory(String imgName,String imgBase64Content)
	{
		try {
			FileOutputStream fileos = new FileOutputStream("C:\\Users\\asharma430\\Documents\\workspace_abuse2\\Web Camm_js\\2\\test"+new Date().getTime()+".png");
			fileos.write(Base64.getDecoder().decode(imgBase64Content.split(",")[1]));
			fileos.close();
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
}

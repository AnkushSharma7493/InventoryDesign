package com.dm.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.dm.domain.Transaction;

@Repository
@Qualifier("transaction")
public interface TransactionRepository extends CrudRepository<Transaction, Integer> {
	
	public List<Transaction> findAllByTransactionidGreaterThanAndTransactionidLessThanEqual(Integer startIndex, Integer endIndex);
	
//	public List<Transaction> findAllByTransactionidGreaterThanEqualAndTransactionidLessThanEqualByOrderByDateDesc(Integer startIndex, Integer endIndex);

	// public List<Transaction> findAllByOrderByDateAsc();
	 
	// public List<Transaction> findAllByOrderByDateDesc();
}


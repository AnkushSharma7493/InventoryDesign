package com.dm.response;

import java.util.List;

import com.dm.domain.User;

public class UserResponse extends Response{
	
	private List<User> users;
	private String role;
	
	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public List<User> getUsers() {
		return users;
	}

	public void setUsers(List<User> users) {
		this.users = users;
	}
}

package com.dm.request;

public class ImageRequest extends BaseRequest{
	
	private String imageName;
	private String imageContent;
	
	public String getImageName() {
		return imageName;
	}
	public void setImageName(String imageName) {
		this.imageName = imageName;
	}
	public String getImageContent() {
		return imageContent;
	}
	public void setImageContent(String imageContent) {
		this.imageContent = imageContent;
	}
	
	

}

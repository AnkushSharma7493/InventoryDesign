package com.dm.request;

public class FilterCriteria {
	
	private String startDate;
	private String endDate;
	private String startLimit;
	private String endLimit;
	
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getStartLimit() {
		return startLimit;
	}
	public void setStartLimit(String startLimit) {
		this.startLimit = startLimit;
	}
	public String getEndLimit() {
		return endLimit;
	}
	public void setEndLimit(String endLimit) {
		this.endLimit = endLimit;
	}

}


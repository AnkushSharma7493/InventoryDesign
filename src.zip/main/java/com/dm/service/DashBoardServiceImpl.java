package com.dm.service;

import java.util.Base64;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.dm.domain.Transaction;
import com.dm.repository.TransactionRepository;
import com.dm.request.TransactionRequest;

@Service
@Qualifier("dashboardService")
public class DashBoardServiceImpl extends BaseService{

	@Autowired
	@Qualifier("transaction")
	TransactionRepository transaction;
	
	/**
	 * 
	 * @param request
	 * @return
	 */
	public List<Transaction> getTransactions(TransactionRequest request) {
		// get table count
		int totalCount = (int) transaction.count();
		int startIndex=0;
		int endIndex=0;
		
		if(totalCount>5)
		{
			if(request.getStartIndex()!=null && request.getEndIndex()!=null)
			{
				startIndex=Integer.parseInt(request.getStartIndex());
				endIndex=Integer.parseInt(request.getEndIndex());
			}
			else
			{
				 startIndex = totalCount-4;
				 endIndex= totalCount;
			}
			return transaction.findAllByTransactionidGreaterThanAndTransactionidLessThanEqual(startIndex, endIndex);
		}
		else
		{
			return (List<Transaction>) transaction.findAll();
		}
	}
	
	/**
	 * 
	 * @param startIndex
	 * @param endIndex
	 * @return
	 */
	public List<Transaction> getFilteredTransaction(int startIndex,int endIndex)
	{
		return transaction.findAllByTransactionidGreaterThanAndTransactionidLessThanEqual(startIndex, endIndex);
	}
	
	
	public Integer getRecordCount()
	{
		return (int) transaction.count();
	}
	
	public boolean setTransaction(Transaction trans)
	{
		if(trans.getImageStream()!=null)
		{
		trans.setImage(Base64.getDecoder().decode(trans.getImageStream().split(",")[1]));
			trans.setImageStream(null);
		}
		trans.setDateView(new Date().toString());
		Transaction tr = transaction.save(trans);
		
		if(tr.getTransactionid()!=null)
		{
			return true;
		}
		return false;
	}
}

'use strict';

var dashboardControllers = angular.module('dashboardControllers', []);

dashboardControllers
		.controller(
				'dashboardController',
				[
						'$scope',
						'DashboardServices',
						'$http',
						function($scope, DashboardServices, $http) {
							$scope.processTransactions=[];
							$scope.applicationState="Login";
							$scope.recordCounts=["5","10","20","50"];
							$scope.pageNumberCount=["1"];
							$scope.tableMode="PROCESS";
							$scope.schedules=[];
							$scope.credentails=[];
							$scope.newSchedule=false;
							$scope.passwordVisibleStatus=false;
							$scope.processNames=[];
							$scope.commandList=[];
							$scope.login={};
							$scope.commandViewarray=[];
							$scope.userRole="ADMIN";
							//$scope.userRole="USER";
							$scope.viewPicture=false;
							$scope.record={};
							$scope.transaction=[];
							//capute image
							 $scope.width = 320;    // We will scale the photo width to this
							 $scope.height = 0;     // This will be computed based on the input stream
							 $scope.streaming = false;
							 $scope.video=null;
							 $scope.canvas=null;
							 $scope.photo=null;
							 $scope.totalCount=0;
							 $scope.selectedNumberOfRecords=5;
							 $scope.activePage=0;
							 $scope.captureMode=true;
							 
							$scope.init = function() {
								
								// Load records from File DB
								$scope.getRecords();
							}
							
							/********************************************************************************************************/
							/******************************************   CAMERA ACTIONS  *******************************************/
							/********************************************************************************************************/
							
							// video camera handling
							$scope.startStreaming=function()
							{
								$scope.video = document.getElementById('video');	
								$scope.canvas = document.getElementById('canvas');
								$scope.photo = document.getElementById('photo');
								
								// get connection with web camera
								navigator.mediaDevices.getUserMedia({video: true, audio: false})
								    .then(function(stream) {
								    	$scope.video.srcObject = stream;
								    	$scope.track = stream.getTracks()[0]; 
								    	$scope.video.play();
								    })
								    .catch(function(err) {
								      console.log("UNABLE TO DETECT WEB CAMERA, PLEASE VERIFY THE CAMERA CONNECTION: " + err);
								    });
								
								
								// START CAPTURING VIDEO STREAM
								 $scope.video.addEventListener('canplay', function(ev){
								      if (!$scope.streaming) {
								    	  $scope.height = $scope.video.videoHeight / ($scope.video.videoWidth/$scope.width);
								      
								        // Firefox currently has a bug where the height can't be read from
								        // the video, so we will make assumptions if this happens.
								      
								        if (isNaN($scope.height)) {
								        	$scope.height = $scope.width / (4/3);
								        }
								      
								        $scope.video.setAttribute('width', $scope.width);
								        $scope.video.setAttribute('height', $scope.height);
								        $scope.canvas.setAttribute('width', $scope.width);
								        $scope.canvas.setAttribute('height', $scope.height);
								        $scope.streaming = true;
								        console.log("stream status from video event : "+$scope.streaming);
								      }
								    }, false);
								 $scope.viewPicture=true;
							}
							
							$scope.stopStreaming=function()
							{
								$scope.track.stop();
							}
								
								
						 // Capture a photo by fetching the current contents of the video
						  // and drawing it into a canvas, then converting that to a PNG
						  // format data URL. By drawing it on an offscreen canvas and then
						  // drawing that to the screen, we can change its size and/or apply
						  // other changes before drawing it.

						  $scope.takepicture=function() {
							  
						    var context = $scope.canvas.getContext('2d');
						    if ($scope.width && $scope.height) {
						    	$scope.canvas.width = $scope.width;
						    	$scope.canvas.height = $scope.height;
						    	context.drawImage(video, 0, 0, $scope.width, $scope.height);
						    
						    $scope.record.imageStream = $scope.canvas.toDataURL('image/png');
						    $scope.photo.setAttribute('src', $scope.record.imageStream);
						    } else {
						    	$scope.clearphoto();
						    }
						    $scope.viewPicture=!$scope.viewPicture;	
						    $scope.stopStreaming(); // stop ctreaming
						  }
						  
						  // Fill the photo with an indication that none has been captured.
						  $scope.clearphoto=function() {
						    var context = $scope.canvas.getContext('2d');
						    context.fillStyle = "#AAA";
						    context.fillRect(0, 0, $scope.canvas.width, $scope.canvas.height);

						    $scope.imgData = $scope.canvas.toDataURL('image/png');
						    $scope.photo.setAttribute('src', $scope.imgData);
						  }
						  
						  // view photo
						  $scope.viewPhoto=function(index)
						  {
							  $scope.captureMode=false;
							  var stream = "data:image/png;base64,"+$scope.transaction[index].image;
							  var photo = document.getElementById('photoViewer');
							  photo.setAttribute('src', stream);
						  }
						  
						  $scope.flipCM=function()
						  {
							  $scope.captureMode=!$scope.captureMode;
						  }
						  
						  	/********************************************************************************************************/
							/******************************************TRANSACTION ACTIONS*******************************************/
							/********************************************************************************************************/
						
						  
							$scope.userLogin=function()
							{
								DashboardServices.login($scope.login).then(
										function(data) {
											if (data != undefined && data != null && data.code=="200" ) 
											{
												$scope.login.status="ACTIVE";
												//$scope.login.userName=data.userName;
												$scope.applicationState="Dashboard";
												$scope.login.api_key=data.api_key;
												$scope.init();
											}
											else
											{
												alert("Exception : "+data.message);
											}
										});
								
								
							}
							
							$scope.logout=function()
							{
								DashboardServices.logout($scope.login).then(
										function(data) {
											if (data != undefined && data != null && data.code=="200" ) 
											{
												$scope.login.status="INACTIVE";
												$scope.applicationState="Login";
												$scope.login.api_key=data.api_key;
											}
											else
											{
												alert("Exception : "+data.message);
											}
										});
								
								
							}
							
							/********************************************************************************************************/
							/****************************************** GET TRANSACTIONS  *******************************************/
							/********************************************************************************************************/
							
							  // save data into DB
							  $scope.saveTransaction=function()
							  {
								  if($scope.verifyNull($scope.record.first_id) && $scope.verifyNull($scope.record.first_id_match) && $scope.verifyNull($scope.record.second_id) 
										  && $scope.verifyNull($scope.record.second_id_match) && $scope.verifyNull($scope.record.cargo_shipment_acceptor) && $scope.verifyNull($scope.record.shipper_company_name) 
										  && $scope.verifyNull($scope.record.iac_employee) && $scope.verifyNull($scope.record.imageStream))
								  {
										var req={};
									    req.api_key=$scope.login.api_key;
									    req.userName="admin"
									    req.transaction=$scope.record;
									    
									    DashboardServices.addRecord(req).then(
												function(data) {
													if (data != undefined && data != null && data.code=="200") 
													{
														alert("Record Saved Successfully !");
														$scope.record.first_id=null;
														$scope.record.first_id_match=null;
														$scope.record.second_id=null;
														$scope.record.second_id_match=null;
														$scope.record.cargo_shipment_acceptor=null;
														$scope.record.shipper_company_name=null;
														$scope.record.iac_employee=null;
														$scope.record.imageStream=null;
													}
													else
													{
														alert("Exception : "+data.message);
													}
												});
								  }
								  else
								  {
									  
									  alert("VALIDATION FAILED ! PROVIDE ALL VALUES");
								  }
							  }
							
							  /**
							   *  Fetch records from DB 
							   * */
							$scope.getRecords = function(startIndex,endIndex) {
								
								var req={};
								req.api_key=$scope.login.api_key;
								req.userName="admin"
									
								if($scope.verifyNull(startIndex) && $scope.verifyNull(endIndex))
								{
									req.startIndex=startIndex;
									req.endIndex=endIndex;
								}
							
								DashboardServices.getRecords(req).then(
												function(data) {
													$scope.transaction=[];
													if (data.code=="200" && data != null) 
													{
														$scope.transaction = data.transaction;
														$scope.postRecordUpdate(data.count);
													}
													else
													{
														alert("Exception : "+data.message);
													}
												});
							}
							
							
							$scope.postRecordUpdate=function(count)
							{
								$scope.totalCount=count; // update total count
								$scope.pageNumberCount=[]; // set pagination page view
								
								var temp=$scope.totalCount;
								var index=1;
								
								while(temp>0)
								{
									temp=temp-$scope.selectedNumberOfRecords;
									$scope.pageNumberCount.push(index);
									index++;
								}
							}
							
							/* download imag3 */
							$scope.downloadImage=function(index)
							{
								var prefix="data:image/png;base64,";
								var base64 = prefix+$scope.transaction[index].image;
								$scope.saveAsFile(base64,$scope.transaction[index].first_id);
								
							}
							
							  //download pic
							  $scope.saveAsFile=function(base64,fileName) {
								    var link = document.createElement("a");
								    link.setAttribute("href", base64);
								    link.setAttribute("download", fileName);
								    link.click();
								}
							
							  
							  
							  $scope.onCountChange=function(selectedNumberOfRecords)
							  {
								  $scope.selectedNumberOfRecords=selectedNumberOfRecords // update centralised variable
								  var startIndex=parseInt($scope.totalCount)-parseInt(selectedNumberOfRecords);
								  var endIndex=$scope.totalCount
								  if(startIndex<0)
								  {
									  startIndex=0;
								  }
								  $scope.getRecords(startIndex,endIndex);
							  }
							  
							  
							  $scope.selectPage=function(page)
							  {
								  $scope.activePage=page-1;
								  var startIndex =parseInt($scope.totalCount)-parseInt($scope.selectedNumberOfRecords)*parseInt(page);
								  var endIndex = parseInt(startIndex)+parseInt($scope.selectedNumberOfRecords);
								  $scope.getRecords(startIndex,endIndex);
							  }
							  
							/********************************************************************************************************/
							/************************************************utility function****************************************/
							/********************************************************************************************************/
							
							$scope.setTasks=function(row,index)
							{
								$scope.selectedTasks=row;
								$scope.tableMode="TASK";
							}
							
							$scope.setProcessView=function()
							{
								$scope.tableMode="PROCESS";
							}
							
							$scope.deleteRow=function(array)
							{
								array.push({});
							}
							
							$scope.addRow=function(credential)
							{
								credential.push({});
							}
							
							$scope.toggleEnable = function(index, array) {
								if (array[index].saved == undefined) {
									array[index].saved = false;
								} else {
									array[index].saved = !array[index].saved;
								}
							}
							
							$scope.verifyNull=function(data)
							{
								if(data==undefined || data==null || data=="")
								{
									return false;
								}
								else
								{
									return true;
								}
							}
							
							
							
							
							//
							//
							//
							
							    $scope.savePDF = function(){
							      
							      var pdf = new jsPDF('p','pt','a4');
							      //var source = document.getElementById('table-container').innerHTML;
							      console.log(document.getElementById('table-container'));
							      var margins = {
							        top: 25,
							        bottom: 60,
							        left: 20,
							        width: 522
							      };
							      // all coords and widths are in jsPDF instance's declared units
							      // 'inches' in this case
							    pdf.text(20, 20, 'Hello world.');
							     pdf.addHTML(document.body, margins.top, margins.left, {}, function() {
							       pdf.save('test.pdf');
							     });
							    };

							    $scope.data = [
							      {
							        id: 1,
							        name: 'MyName',
							        age: '21',
							        class:'asdf-123',
							        hi:'Hello world'
							      },
							      {
							        id: 2,
							        name: 'MyName',
							        age: '21',
							        class:'asdf-123',
							        hi:'Hello world'
							      },
							      {
							        id: 3,
							        name: 'MyName',
							        age: '21',
							        class:'asdf-123',
							        hi:'Hello world'
							      },
							      {
							        id: 4,
							        name: 'MyName',
							        age: '21',
							        class:'asdf-123',
							        hi:'Hello world'
							      },
							      {
							        id: 5,
							        name: 'MyName',
							        age: '21',
							        class:'asdf-123',
							        hi:'Hello world'
							      },
							      {
							        id: 6,
							        name: 'MyName',
							        age: '21',
							        class:'asdf-123',
							        hi:'Hello world'
							      },
							      {
							        id: 7,
							        name: 'MyName',
							        age: '21',
							        class:'asdf-123',
							        hi:'Hello world'
							      }
							    ];
					

							
						} ]);

'use strict';

angular.module('DashboardApp', ['dashboardControllers','DashboardServices']);


package com.dm.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.dm.domain.User;

@Repository
@Qualifier("userRepo")
public interface UserRepository extends CrudRepository<User, Integer>{
	
	public List<User> findALLByUserName(String userName);

}

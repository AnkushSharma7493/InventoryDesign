package com.dm.configuration;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.apache.log4j.Logger;

public class ApplicationContext {
	private static Logger logger  = Logger.getLogger(ApplicationContext.class);
	/*
	 * properties : load properties from property file
	 * fileTemplateMapper
	 * */
	
	static
	{
		System.out.println("--------------------->");
	}
	
	public static Properties appProperties=null;
	public static Map<String,String> properties=new HashMap<>();

	
	public static void loadProperties()
	{
		logger.info("load Properties into ApplicationContext");
		File configFile = new File("C:\\Users\\Public\\Automation\\Config\\appConfig.property");
		appProperties=new Properties();
		try {
		    FileReader reader = new FileReader(configFile);
		    appProperties.load(reader);
		    for(Object key : appProperties.keySet()){
				properties.put((String)key,(String)appProperties.get(key));
			}
		}catch (IOException e1) {
			e1.printStackTrace();
		}
	}
	
	public static void addProperty(String key,String value)
	{
		logger.info("Add Propery into ApplicationContext"+" Key :"+key+" Value: "+value);
		properties.put(key, value);
	}
	
}

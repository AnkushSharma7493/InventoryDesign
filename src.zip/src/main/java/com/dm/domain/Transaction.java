package com.dm.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.CreationTimestamp;

@Entity
@Table(name="transaction")
public class Transaction {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer transactionid;
	
	@Column(name="first_id")
	private String first_id;
	
	@Column(name="first_id_match")
	private String first_id_match;
	
	@Column(name="second_id")
	private String second_id;
	
	@Column(name="second_id_match")
	private String second_id_match;
	
	@Column(name="cargo_shipment_acceptor")
	private String cargo_shipment_acceptor;
	
	@Column(name="shipper_company_name")
	private String shipper_company_name;
	
	@Column(name="iac_employee")
	private String iac_employee;
	
	@Lob
	@Column(name="image")
    private byte[] image;
	
	private String dateView;
	
	@Column(name="date")
	@CreationTimestamp
	@Temporal(TemporalType.TIMESTAMP)
	private Date date;
	
	public String getDateView() {
		return dateView;
	}
	public void setDateView(String dateView) {
		this.dateView = dateView;
	}
	private String imageStream;
	
	public String getImageStream() {
		return imageStream;
	}
	public void setImageStream(String imageStream) {
		this.imageStream = imageStream;
	}
	public Integer getTransactionid() {
		return transactionid;
	}
	public void setTransactionid(Integer transactionid) {
		this.transactionid = transactionid;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public String getFirst_id() {
		return first_id;
	}
	public void setFirst_id(String first_id) {
		this.first_id = first_id;
	}
	public String getFirst_id_match() {
		return first_id_match;
	}
	public void setFirst_id_match(String first_id_match) {
		this.first_id_match = first_id_match;
	}
	public String getSecond_id() {
		return second_id;
	}
	public void setSecond_id(String second_id) {
		this.second_id = second_id;
	}
	public String getSecond_id_match() {
		return second_id_match;
	}
	public void setSecond_id_match(String second_id_match) {
		this.second_id_match = second_id_match;
	}
	public String getCargo_shipment_acceptor() {
		return cargo_shipment_acceptor;
	}
	public void setCargo_shipment_acceptor(String cargo_shipment_acceptor) {
		this.cargo_shipment_acceptor = cargo_shipment_acceptor;
	}
	public String getShipper_company_name() {
		return shipper_company_name;
	}
	public void setShipper_company_name(String shipper_company_name) {
		this.shipper_company_name = shipper_company_name;
	}
	public String getIac_employee() {
		return iac_employee;
	}
	public void setIac_employee(String iac_employee) {
		this.iac_employee = iac_employee;
	}
	public byte[] getImage() {
		return image;
	}
	public void setImage(byte[] image) {
		this.image = image;
	}
}

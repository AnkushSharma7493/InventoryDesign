package com.dm.response;

import java.util.List;

import com.dm.domain.Transaction;

public class TransactionResponse extends Response {

	private List<Transaction> transaction;
	private Integer count;

	public Integer getCount() {
		return count;
	}

	public void setCount(Integer count) {
		this.count = count;
	}

	public List<Transaction> getTransaction() {
		return transaction;
	}

	public void setTransaction(List<Transaction> transaction) {
		this.transaction = transaction;
	}
}

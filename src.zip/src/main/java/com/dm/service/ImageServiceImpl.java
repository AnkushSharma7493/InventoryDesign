package com.dm.service;

import com.dm.request.ImageRequest;

public class ImageServiceImpl {

	
	public boolean saveImage(ImageRequest request) {
		// TODO Auto-generated method stub
		return true;
	}

	
	public String[] getImages() {
		// TODO Auto-generated method stub
		return null;
	}

}

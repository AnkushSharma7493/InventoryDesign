package com.dm.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.dm.domain.User;
import com.dm.repository.UserRepository;
import com.dm.request.BaseRequest;

public class BaseService{

	@Autowired
	@Qualifier("userRepo")
	UserRepository userRepo;
	
	public boolean verifyToken(BaseRequest request) {
		User user = userRepo.findALLByUserName(request.getUserName()).get(0);
		if(request.getApi_key().equals(user.getApiKey()))
		{
			return true;
		}
		return false;
	}

}

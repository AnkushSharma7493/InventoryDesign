package com.dm.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.dm.configuration.UtilityHealper;
import com.dm.domain.User;
import com.dm.repository.UserRepository;
import com.dm.request.BaseRequest;
import com.dm.request.LoginRequest;
import com.dm.request.UserRequest;

@Service
@Qualifier("userService")
public class UserServiceImpl extends BaseService {

	@Autowired
	@Qualifier("userRepo")
	UserRepository userRepo;

	public User login(LoginRequest request) {
		// fetch record 
		List<User> users=userRepo.findALLByUserName(request.getUserName());
		User user=null;
		
		if(users.size()>0)
		{
			user=users.get(0);
			if (request.getPassword().equals(user.getPassword())) {
				user.setApiKey(UtilityHealper.generateKey());
				userRepo.save(user);
			}
		}
		else
		{
			if("admin".equals(request.getUserName()))
			{
				UserRequest userReq = new UserRequest();
		    	user = new User();
		    	user.setUserName("admin");
				user.setPassword("admin@123");
		    	user.setRole("ADMIN");
		    	user.setApiKey(UtilityHealper.generateKey());
		    	userReq.setUser(user);
		    	setUser(userReq);
			}
		}
		return user;
	}

	public boolean logout(LoginRequest request) {
		User user = userRepo.findALLByUserName(request.getUserName()).get(0);
		
		if(user!=null && request.getApi_key().equals(user.getApiKey()))
		{
			user.setApiKey(null);
			userRepo.save(user);
			return true;
		}
		return false;
	}

	/**
	 * Get All users
	 * @param request
	 * @return
	 */
	public List<User> getAllUsers(BaseRequest request)
	{
		if(verifyToken(request))
		{
			return (List<User>) userRepo.findAll();
		}
		
		return null;
	}
	
	public boolean addUser(UserRequest request)
	{
		if(verifyToken(request))
		{
			try {
				setUser(request);
			}catch(Exception e)
			{
				e.printStackTrace();
				return false;
			}
		}
		return true;
	}
	
	public void setUser(UserRequest request)
	{
		request.getUser().setDate(new Date());
		userRepo.save(request.getUser());
	}
}

package com.dm.SpringRest;

public class Launcher 
{
	/*	public static void main(String[] args)
		{
			new Thread(new Runnable() {
				@Override
				public void run() {
					try {
						Thread.sleep(15000);
							Process p = Runtime.getRuntime().exec(new String[] {"\"/Program Files (x86)/Google/Chrome/Application/chrome.exe\"","http://localhost:8080/index.html"});
							p.waitFor();
						} catch (Exception e) {
							e.printStackTrace();
						}
				}
			}).start();
		}*/
}
